import time,string,dataclasses, random, os, json, requests, xbmcaddon, xbmcgui, xbmc
from datetime import datetime
from hashlib import md5, sha256, sha1
from dateutil.parser import parse
from urllib.parse import quote, urlparse
from resources.lib import utils
addon = xbmcaddon.Addon()
monitor = xbmc.Monitor()

tokencache = os.path.join(utils.cachepath, "token.json")

@dataclasses.dataclass
class Token:
	value= None
	time= 0
	mac = None
	url = None

class StalkerPortal:
	def __init__(self, portal_url, mac):
		self.url = portal_url
		self.portal_url = portal_url.rstrip("/").replace('/c', '/server/load.php')
		self.mac = mac.strip()
		self.serial = self.generate_serial(self.mac)
		self.device_id = self.generate_device_id()
		self.device_id1 = self.device_id
		self.device_id2 = self.device_id
		#self.session = requests.Session()
		self.__token = Token()
		self.__load_cache()
		self.random= None
		self.headers = self.generate_headers()
		self.backoff_factor = 1

	def __load_cache(self):
		utils.log('Loading token from cache')
		try:
			with open(tokencache, 'r') as f:
				self.__token.__dict__ = json.loads(f.read())
		except Exception as e: utils.log(e)

	def __save_cache(self):
		utils.log('Saving token to cache')
		self.__token.time = time.time()
		self.__token.mac = self.mac
		self.__token.url = self.portal_url
		with open(tokencache, 'w') as f:
			json.dump(self.__token.__dict__, f, indent=2)

	def generate_serial(self, mac):
		md5_hash = md5(mac.encode()).hexdigest()
		return md5_hash[:13].upper()

	def generate_device_id(self):
		mac_exact = self.mac.strip()
		return sha256(mac_exact.encode()).hexdigest().upper()

	def generate_random_value(self):
		return ''.join(random.choices('0123456789abcdef', k=40))

	def generate_headers(self, include_auth= True, include_token= True, custom_headers= None):
		headers = {}
		headers["Accept"] = "*/*"
		headers["User-Agent"] = 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3'
		headers["Referer"] = self.url
		headers["Accept-Language"] = "en-US,en;q=0.5"
		headers["Pragma"] = "no-cache"
		headers["X-User-Agent"] = "Model: MAG250; Link: WiFi"
		headers["Host"] = urlparse(self.portal_url).netloc
		if include_auth and self.__token.value: headers["Authorization"] = f"Bearer {self.__token.value}"
		headers["Cookie"] = self.generate_cookies(include_token=include_token)
		headers["Connection"] = "Close"
		headers["Accept-Encoding"] = "gzip, deflate"
		if custom_headers: headers.update(custom_headers)
		utils.log(f"Generated headers: {headers}")
		return headers

	def generate_cookies(self, include_token= True):
		cookies = {"mac": quote(self.mac),"stb_lang": "en","timezone": quote("Europe/Paris")}
		if include_token and self.__token.value: cookies["token"] = quote(self.__token.value)
		return "; ".join([f"{key}={value}" for key, value in cookies.items()])

	def make_request_with_retries(self, params, retries=0, timeout=5):
		if not params.get("action") in ["handshake", "get_profile"]: self.ensure_token()
		params["JsHttpRequest"] = "1-xml"
		for attempt in range(1, retries + 2):
			try:
				utils.log(f"Attempt {attempt}: GET {self.portal_url} with params={params}")
				response = requests.get(self.portal_url, params=params, headers=self.headers, timeout=timeout)
				utils.log(f"Received response: {response.status_code}")
				a = response.text
				if "IP adresiniz engellenmistir." in a: return "IP BLOCKED"
				elif "js" in a: return json.loads(a)["js"]
				else: 
					faultymac = utils.get_cache("faultymac")
					if not faultymac: faultymac = {}
					if not self.portal_url in faultymac:
						faultymac[self.portal_url] = []
					if self.mac not in faultymac[self.portal_url]:
						faultymac[self.portal_url].append(self.mac)
					utils.set_cache("faultymac" , faultymac)
					continue
			except Exception as e: utils.log(e)
			if attempt < retries:
				sleep_time = self.backoff_factor * (2 ** (attempt - 1))
				utils.log(f"Retrying after {sleep_time} seconds...")
				monitor.waitForAbort(sleep_time)
			else: utils.log(f"All {retries} attempts failed for URL {self.portal_url}")

	def handshake(self):
		random_value = None
		token = None
		try:
			token = self.generate_token()
			prehash = self.generate_prehash(token)
			_params = {"type":"stb","action":"handshake","token":token, "prehash": prehash}
			response = self.make_request_with_retries(_params)
			if response == "IP BLOCKED": return "IP BLOCKED"
			token = response.get("token")
			random_value = response.get("random", None)
			if random_value: self.random = random_value.lower()
			else: self.random = self.generate_random_value()
		except Exception as e: utils.log(e)
		if token:
			self.__token.value = token
			self.__save_cache()
			self.headers["Authorization"] = f"Bearer {token}"

	def generate_token(self):
		token_length = 32
		return ''.join(random.choices(string.ascii_uppercase + string.digits, k=token_length))

	def generate_prehash(self, token):
		hash_object = sha1(token.encode())
		return hash_object.hexdigest()

	def ensure_token(self):
		if self.__token.mac != self.mac or self.__token.url != self.portal_url or self.__token.value is None:
			utils.log("Token not present. Performing handshake to obtain token.")
			a = self.handshake()
			if a == "IP BLOCKED": return "IP BLOCKED"
			self.get_profile()
		elif (time.time() - self.__token.time) > 120:
			utils.log("Token expired. Performing refresh to obtain new token.")
			self.get_profile()
		else: utils.log("Existing token is still valid.")

	def get_profile(self):
		params = {"type": "stb", "action": "get_profile", "hd": "1",
			"ver": "ImageDescription: 0.2.18-r23-250; ImageDate: Thu Sep 13 11:31:16 EEST 2018; PORTAL version: 5.6.2; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c",
			"num_banks": "2",
			"sn": self.serial,
			"stb_type": "MAG250",
			"client_type": "STB",
			"image_version": "218",
			"video_out": "hdmi",
			"device_id": self.device_id1,
			"device_id2": self.device_id2,
			"signature": self.generate_signature(),
			"auth_second_step": "1",
			"hw_version": "1.7-BD-00",
			"not_valid_token": "0",
			"metrics": self.generate_metrics(),
			"hw_version_2": sha1(self.mac.encode()).hexdigest(),
			"timestamp": int(time.time()),
			"api_signature": "262",
			"prehash": ""}
		try:
			response = self.make_request_with_retries(params)
			token = response.get("token")
			if token:
				utils.log(f"Profile token updated: {token}")
				self.__token.value = token
		except Exception as e: utils.log(e)
		else:
			self.__save_cache()
			self.headers["Authorization"] = f"Bearer {self.__token.value}"
			utils.log(f"Updatet headers: {self.headers}")

	def generate_signature(self):
		data = f"{self.mac}{self.serial}{self.device_id1}{self.device_id2}"
		signature = sha256(data.encode()).hexdigest().upper()
		return signature

	def generate_metrics(self):
		if not self.random: self.random = self.generate_random_value()
		metrics = {"mac": self.mac,"sn": self.serial,"type": "STB","model": "MAG250","uid": "","random": self.random}
		metrics_str = json.dumps(metrics)
		return metrics_str

	def get_account_info(self):
		_params = {"type":"account_info","action":"get_main_info"}
		return self.make_request_with_retries(_params)
		
	def genres(self):
		categories = {}
		groups = self.make_request_with_retries({"type":"itv","action":"get_genres"}, retries=2, timeout=10)
		if not groups: return {}
		for i in groups:
			if i.get("title") and i.get("id") and i.get("id") !="*" : categories[i.get("title")] = i.get("id")
		return dict(sorted(list(categories.items()))) 
		
	def check(self):
		try:
			account_info = self.get_account_info()
			if account_info == "IP BLOCKED": 
				addon.setSetting("account_info", "IP BLOCKED")
				addon.setSetting("portal_ok", "IP BLOCKED")
				return "IP BLOCKED"
			elif not account_info:
				addon.setSetting("account_info", "")
				return "ACCOUNT Infos Empty"
			else:
				utils.log(account_info)
				phone =  account_info.get("phone")
				if phone and (time.time()+432000) > datetime.timestamp(parse(phone)):
					faultymac = utils.get_cache("faultymac")
					if not faultymac: faultymac = {}
					if not self.portal_url in faultymac:
						faultymac[self.portal_url] = []
					if self.mac not in faultymac[self.portal_url]:
						faultymac[self.portal_url].append(self.mac)
					utils.set_cache("faultymac" , faultymac)
					addon.setSetting("account_info", "")
					return "ACCOUNT Expired"
				account_info_str = ",".join([f"{k}:{v}" for k, v in account_info.items()])
				addon.setSetting("account_info", account_info_str)
			if not self.genres(): return "No Genres"
			try: 
				chans = self.channels()
				cmd = random.choice(chans)
			except: return "No Channels"
			if cmd["use_http_tmp_link"] == "0": streamurl = cmd['cmd'].split()[-1]
			else: streamurl, headers = self.get_tv_stream_url(cmd['cmd'])
			res = requests.get(streamurl, headers=self.headers ,timeout=10, stream=True)
			status = res.status_code
			if int(status) > 399:
				utils.log(f"Stream: {status}")
				return f"HTTP ERROR %s" % status
			addon.setSetting("portal_ok", "Status OK")
			return True
		except Exception as e: 
			utils.log(e)
			return e
	
	def channels(self):
		response = self.make_request_with_retries({"type":"itv","action":"get_all_channels"}, retries=2, timeout=10)
		if isinstance(response, dict):
			 data= response["data"]
		else: return {}
		chan =  [{"name": a["name"], "cmd": a["cmd"], "use_http_tmp_link": a["use_http_tmp_link"], "tv_genre_id":a["tv_genre_id"]} for a in data]
		return chan

	def get_tv_stream_url(self, cmd):
		cmd = self.make_request_with_retries({"type":"itv","action":"create_link", "cmd":cmd})["cmd"]
		return cmd.split()[-1], self.headers
				
def get_genres():
	titles, ids, preselect = [], [], []
	portal = StalkerPortal(utils.get_cache_or_setting("stalkerurl"), utils.get_cache_or_setting("mac"))
	gruppen = portal.genres()
	for title, groupid in  gruppen.items():
		titles.append(title.encode().decode("ascii", errors="ignore"))
		ids.append(groupid)
	oldgroups = utils.get_cache("stalker_groups")
	if oldgroups: preselect = [ids.index(i) for i in oldgroups]
	indicies = utils.selectDialog(titles, "Choose Groups", True, preselect)
	if indicies:
		group = [ids[i] for i in indicies]
		utils.set_cache("stalker_groups", group)
		return group
	return []
	
def choose_portal():
	maclists = requests.get("https://michaz1988.github.io/maclist.json").json()
	a, b, c = [], [], []
	for key, value in maclists.items():
		a.append(key)
		b.append(value)
		c.append("%s, %s mac" % (utils.urlsplit(key).hostname, len(value)))
	indicies = utils.selectDialog(c, "Stalkerurl auswählen")
	if indicies >=0: check_portal(a[indicies], b[indicies])

def new_mac():
	utils.log("Getting New Mac")
	url = utils.get_cache("stalkerurl")
	maclists = requests.get("https://michaz1988.github.io/maclist.json").json()
	maclist = maclists[url]
	return check_portal(url, maclist)
	
def check_portal(url, maclist):
	faultymac = utils.get_cache("faultymac")
	if not faultymac: faultymac = {}
	faultymaclist = faultymac.get(url, [])
	progress = xbmcgui.DialogProgress()
	if utils.get_cache("stalkerurl") != url:
		utils.del_cache("stalker_groups")
	utils.set_cache("stalkerurl", url)
	addon.setSetting("stalkerurl", url)
	utils.del_cache("sta_channels")
	progress.create("TESTE STALKER MAC ADRESSEN", f"Verfügbare Mac Adressen {len(maclist)}")
	retry = int(addon.getSetting("stalker_retry"))
	i = 0
	while not monitor.abortRequested() and i <= retry:
		i+=1
		if i >=1: monitor.waitForAbort(2)
		if (progress.iscanceled()):
			progress.close()
			break
		utils.log(f"Versuch :{i}")
		addon.setSetting("portal_ok", f"Teste Mac Adressen, Versuch :{i}/{str(retry)}")
		progress.update(int(i/retry*100),f"Teste Mac Adressen, Versuch :{i}/{str(retry)}")
		while True:
			mac =random.choice(maclist)
			if mac not in faultymaclist: break
		addon.setSetting("mac", mac)
		utils.set_cache("mac", mac)
		portal =  StalkerPortal(url, mac)
		check = portal.check()
		if check == True:
			progress.close()
			xbmc.executebuiltin("Container.Refresh")
			return
		elif check == "IP BLOCKED":
			progress.update(int(i/retry*100),f"Teste Mac Adressen, Versuch :{i}/{str(retry)}\nFehler {check}")
			progress.close()
			xbmcgui.Dialog().notification('VAVOO.TO', 'IP BLOCKED anderes Portal auswählen, deaktiviere Stalker', xbmcgui.NOTIFICATION_ERROR, 2000)
			addon.setSetting("stalker", "false")
			return False
		else: progress.update(int(i/retry*100),f"Teste Mac Adressen, Versuch :{i}/{str(retry)}\nFehler {check}")
	progress.close()
	xbmc.executebuiltin("Container.Refresh")
	utils.log("Keine funktionierende Mac")
	addon.setSetting("portal_ok", "Keine gültige Mac")
	return False